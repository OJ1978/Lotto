﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrPower = New System.Windows.Forms.Timer(Me.components)
        Me.pnl50 = New System.Windows.Forms.Panel()
        Me.pnl41 = New System.Windows.Forms.Panel()
        Me.pnl36 = New System.Windows.Forms.Panel()
        Me.pnl35 = New System.Windows.Forms.Panel()
        Me.pnl34 = New System.Windows.Forms.Panel()
        Me.pnl33 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.pnlDrum = New System.Windows.Forms.Panel()
        Me.pnl49 = New System.Windows.Forms.Panel()
        Me.pnl9 = New System.Windows.Forms.Panel()
        Me.pnl20 = New System.Windows.Forms.Panel()
        Me.pnlPowerDrum = New System.Windows.Forms.Panel()
        Me.pnl23 = New System.Windows.Forms.Panel()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.pnl22 = New System.Windows.Forms.Panel()
        Me.pnl26 = New System.Windows.Forms.Panel()
        Me.pnl5 = New System.Windows.Forms.Panel()
        Me.pnl38 = New System.Windows.Forms.Panel()
        Me.pnl25 = New System.Windows.Forms.Panel()
        Me.tmrBalls = New System.Windows.Forms.Timer(Me.components)
        Me.btnPowerBall = New System.Windows.Forms.Button()
        Me.pnl18 = New System.Windows.Forms.Panel()
        Me.pnl17 = New System.Windows.Forms.Panel()
        Me.pnl8 = New System.Windows.Forms.Panel()
        Me.pnl6 = New System.Windows.Forms.Panel()
        Me.pnl47 = New System.Windows.Forms.Panel()
        Me.pnl48 = New System.Windows.Forms.Panel()
        Me.pnl46 = New System.Windows.Forms.Panel()
        Me.pnl40 = New System.Windows.Forms.Panel()
        Me.pnl45 = New System.Windows.Forms.Panel()
        Me.pnl44 = New System.Windows.Forms.Panel()
        Me.pnl43 = New System.Windows.Forms.Panel()
        Me.pnl42 = New System.Windows.Forms.Panel()
        Me.pnl39 = New System.Windows.Forms.Panel()
        Me.pnl37 = New System.Windows.Forms.Panel()
        Me.pnl31 = New System.Windows.Forms.Panel()
        Me.pnl29 = New System.Windows.Forms.Panel()
        Me.pnl32 = New System.Windows.Forms.Panel()
        Me.pnl30 = New System.Windows.Forms.Panel()
        Me.pnl28 = New System.Windows.Forms.Panel()
        Me.pnl27 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnl24 = New System.Windows.Forms.Panel()
        Me.pnlResults = New System.Windows.Forms.Panel()
        Me.pnl21 = New System.Windows.Forms.Panel()
        Me.pnl19 = New System.Windows.Forms.Panel()
        Me.pnl2 = New System.Windows.Forms.Panel()
        Me.pnl13 = New System.Windows.Forms.Panel()
        Me.pnl16 = New System.Windows.Forms.Panel()
        Me.pnl15 = New System.Windows.Forms.Panel()
        Me.pnl11 = New System.Windows.Forms.Panel()
        Me.pnl14 = New System.Windows.Forms.Panel()
        Me.pnl12 = New System.Windows.Forms.Panel()
        Me.pnl10 = New System.Windows.Forms.Panel()
        Me.pnl4 = New System.Windows.Forms.Panel()
        Me.pnl7 = New System.Windows.Forms.Panel()
        Me.pnl3 = New System.Windows.Forms.Panel()
        Me.pnl1 = New System.Windows.Forms.Panel()
        Me.pnlPowerBall = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pnlResults.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmrPower
        '
        Me.tmrPower.Interval = 20
        '
        'pnl50
        '
        Me.pnl50.BackColor = System.Drawing.Color.Black
        Me.pnl50.Location = New System.Drawing.Point(287, 246)
        Me.pnl50.Name = "pnl50"
        Me.pnl50.Size = New System.Drawing.Size(40, 40)
        Me.pnl50.TabIndex = 58
        '
        'pnl41
        '
        Me.pnl41.BackColor = System.Drawing.Color.Black
        Me.pnl41.Location = New System.Drawing.Point(0, 205)
        Me.pnl41.Name = "pnl41"
        Me.pnl41.Size = New System.Drawing.Size(40, 40)
        Me.pnl41.TabIndex = 49
        '
        'pnl36
        '
        Me.pnl36.BackColor = System.Drawing.Color.Black
        Me.pnl36.Location = New System.Drawing.Point(123, 164)
        Me.pnl36.Name = "pnl36"
        Me.pnl36.Size = New System.Drawing.Size(40, 40)
        Me.pnl36.TabIndex = 44
        '
        'pnl35
        '
        Me.pnl35.BackColor = System.Drawing.Color.Black
        Me.pnl35.Location = New System.Drawing.Point(82, 164)
        Me.pnl35.Name = "pnl35"
        Me.pnl35.Size = New System.Drawing.Size(40, 40)
        Me.pnl35.TabIndex = 43
        '
        'pnl34
        '
        Me.pnl34.BackColor = System.Drawing.Color.Black
        Me.pnl34.Location = New System.Drawing.Point(41, 164)
        Me.pnl34.Name = "pnl34"
        Me.pnl34.Size = New System.Drawing.Size(40, 40)
        Me.pnl34.TabIndex = 42
        '
        'pnl33
        '
        Me.pnl33.BackColor = System.Drawing.Color.Black
        Me.pnl33.Location = New System.Drawing.Point(0, 164)
        Me.pnl33.Name = "pnl33"
        Me.pnl33.Size = New System.Drawing.Size(40, 40)
        Me.pnl33.TabIndex = 41
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnClear.Location = New System.Drawing.Point(14, 332)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(107, 31)
        Me.btnClear.TabIndex = 80
        Me.btnClear.TabStop = False
        Me.btnClear.Text = "Clear All"
        Me.btnClear.UseMnemonic = False
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'pnlDrum
        '
        Me.pnlDrum.BackColor = System.Drawing.Color.Black
        Me.pnlDrum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlDrum.Location = New System.Drawing.Point(466, 40)
        Me.pnlDrum.Name = "pnlDrum"
        Me.pnlDrum.Size = New System.Drawing.Size(350, 500)
        Me.pnlDrum.TabIndex = 90
        '
        'pnl49
        '
        Me.pnl49.BackColor = System.Drawing.Color.Black
        Me.pnl49.Location = New System.Drawing.Point(0, 246)
        Me.pnl49.Name = "pnl49"
        Me.pnl49.Size = New System.Drawing.Size(40, 40)
        Me.pnl49.TabIndex = 57
        '
        'pnl9
        '
        Me.pnl9.BackColor = System.Drawing.Color.Black
        Me.pnl9.Location = New System.Drawing.Point(0, 41)
        Me.pnl9.Name = "pnl9"
        Me.pnl9.Size = New System.Drawing.Size(40, 40)
        Me.pnl9.TabIndex = 17
        '
        'pnl20
        '
        Me.pnl20.BackColor = System.Drawing.Color.Black
        Me.pnl20.Location = New System.Drawing.Point(123, 82)
        Me.pnl20.Name = "pnl20"
        Me.pnl20.Size = New System.Drawing.Size(40, 40)
        Me.pnl20.TabIndex = 28
        '
        'pnlPowerDrum
        '
        Me.pnlPowerDrum.BackColor = System.Drawing.Color.Black
        Me.pnlPowerDrum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlPowerDrum.Location = New System.Drawing.Point(463, 40)
        Me.pnlPowerDrum.Name = "pnlPowerDrum"
        Me.pnlPowerDrum.Size = New System.Drawing.Size(350, 500)
        Me.pnlPowerDrum.TabIndex = 89
        '
        'pnl23
        '
        Me.pnl23.BackColor = System.Drawing.Color.Black
        Me.pnl23.Location = New System.Drawing.Point(246, 82)
        Me.pnl23.Name = "pnl23"
        Me.pnl23.Size = New System.Drawing.Size(40, 40)
        Me.pnl23.TabIndex = 31
        '
        'btnNext
        '
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnNext.Location = New System.Drawing.Point(122, 332)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(107, 31)
        Me.btnNext.TabIndex = 78
        Me.btnNext.TabStop = False
        Me.btnNext.Text = "Next Ball"
        Me.btnNext.UseMnemonic = False
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'pnl22
        '
        Me.pnl22.BackColor = System.Drawing.Color.Black
        Me.pnl22.Location = New System.Drawing.Point(205, 82)
        Me.pnl22.Name = "pnl22"
        Me.pnl22.Size = New System.Drawing.Size(40, 40)
        Me.pnl22.TabIndex = 30
        '
        'pnl26
        '
        Me.pnl26.BackColor = System.Drawing.Color.Black
        Me.pnl26.Location = New System.Drawing.Point(41, 123)
        Me.pnl26.Name = "pnl26"
        Me.pnl26.Size = New System.Drawing.Size(40, 40)
        Me.pnl26.TabIndex = 34
        '
        'pnl5
        '
        Me.pnl5.BackColor = System.Drawing.Color.Black
        Me.pnl5.Location = New System.Drawing.Point(164, 0)
        Me.pnl5.Name = "pnl5"
        Me.pnl5.Size = New System.Drawing.Size(40, 40)
        Me.pnl5.TabIndex = 13
        '
        'pnl38
        '
        Me.pnl38.BackColor = System.Drawing.Color.Black
        Me.pnl38.Location = New System.Drawing.Point(205, 164)
        Me.pnl38.Name = "pnl38"
        Me.pnl38.Size = New System.Drawing.Size(40, 40)
        Me.pnl38.TabIndex = 46
        '
        'pnl25
        '
        Me.pnl25.BackColor = System.Drawing.Color.Black
        Me.pnl25.Location = New System.Drawing.Point(0, 123)
        Me.pnl25.Name = "pnl25"
        Me.pnl25.Size = New System.Drawing.Size(40, 40)
        Me.pnl25.TabIndex = 33
        '
        'tmrBalls
        '
        Me.tmrBalls.Interval = 20
        '
        'btnPowerBall
        '
        Me.btnPowerBall.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnPowerBall.Location = New System.Drawing.Point(230, 332)
        Me.btnPowerBall.Name = "btnPowerBall"
        Me.btnPowerBall.Size = New System.Drawing.Size(107, 31)
        Me.btnPowerBall.TabIndex = 79
        Me.btnPowerBall.TabStop = False
        Me.btnPowerBall.Text = "Power Ball"
        Me.btnPowerBall.UseMnemonic = False
        Me.btnPowerBall.UseVisualStyleBackColor = True
        '
        'pnl18
        '
        Me.pnl18.BackColor = System.Drawing.Color.Black
        Me.pnl18.Location = New System.Drawing.Point(41, 82)
        Me.pnl18.Name = "pnl18"
        Me.pnl18.Size = New System.Drawing.Size(40, 40)
        Me.pnl18.TabIndex = 26
        '
        'pnl17
        '
        Me.pnl17.BackColor = System.Drawing.Color.Black
        Me.pnl17.Location = New System.Drawing.Point(0, 82)
        Me.pnl17.Name = "pnl17"
        Me.pnl17.Size = New System.Drawing.Size(40, 40)
        Me.pnl17.TabIndex = 25
        '
        'pnl8
        '
        Me.pnl8.BackColor = System.Drawing.Color.Black
        Me.pnl8.Location = New System.Drawing.Point(287, 0)
        Me.pnl8.Name = "pnl8"
        Me.pnl8.Size = New System.Drawing.Size(40, 40)
        Me.pnl8.TabIndex = 16
        '
        'pnl6
        '
        Me.pnl6.BackColor = System.Drawing.Color.Black
        Me.pnl6.Location = New System.Drawing.Point(205, 0)
        Me.pnl6.Name = "pnl6"
        Me.pnl6.Size = New System.Drawing.Size(40, 40)
        Me.pnl6.TabIndex = 14
        '
        'pnl47
        '
        Me.pnl47.BackColor = System.Drawing.Color.Black
        Me.pnl47.Location = New System.Drawing.Point(246, 205)
        Me.pnl47.Name = "pnl47"
        Me.pnl47.Size = New System.Drawing.Size(40, 40)
        Me.pnl47.TabIndex = 55
        '
        'pnl48
        '
        Me.pnl48.BackColor = System.Drawing.Color.Black
        Me.pnl48.Location = New System.Drawing.Point(287, 205)
        Me.pnl48.Name = "pnl48"
        Me.pnl48.Size = New System.Drawing.Size(40, 40)
        Me.pnl48.TabIndex = 56
        '
        'pnl46
        '
        Me.pnl46.BackColor = System.Drawing.Color.Black
        Me.pnl46.Location = New System.Drawing.Point(205, 205)
        Me.pnl46.Name = "pnl46"
        Me.pnl46.Size = New System.Drawing.Size(40, 40)
        Me.pnl46.TabIndex = 54
        '
        'pnl40
        '
        Me.pnl40.BackColor = System.Drawing.Color.Black
        Me.pnl40.Location = New System.Drawing.Point(287, 164)
        Me.pnl40.Name = "pnl40"
        Me.pnl40.Size = New System.Drawing.Size(40, 40)
        Me.pnl40.TabIndex = 48
        '
        'pnl45
        '
        Me.pnl45.BackColor = System.Drawing.Color.Black
        Me.pnl45.Location = New System.Drawing.Point(164, 205)
        Me.pnl45.Name = "pnl45"
        Me.pnl45.Size = New System.Drawing.Size(40, 40)
        Me.pnl45.TabIndex = 53
        '
        'pnl44
        '
        Me.pnl44.BackColor = System.Drawing.Color.Black
        Me.pnl44.Location = New System.Drawing.Point(123, 205)
        Me.pnl44.Name = "pnl44"
        Me.pnl44.Size = New System.Drawing.Size(40, 40)
        Me.pnl44.TabIndex = 52
        '
        'pnl43
        '
        Me.pnl43.BackColor = System.Drawing.Color.Black
        Me.pnl43.Location = New System.Drawing.Point(82, 205)
        Me.pnl43.Name = "pnl43"
        Me.pnl43.Size = New System.Drawing.Size(40, 40)
        Me.pnl43.TabIndex = 51
        '
        'pnl42
        '
        Me.pnl42.BackColor = System.Drawing.Color.Black
        Me.pnl42.Location = New System.Drawing.Point(41, 205)
        Me.pnl42.Name = "pnl42"
        Me.pnl42.Size = New System.Drawing.Size(40, 40)
        Me.pnl42.TabIndex = 50
        '
        'pnl39
        '
        Me.pnl39.BackColor = System.Drawing.Color.Black
        Me.pnl39.Location = New System.Drawing.Point(246, 164)
        Me.pnl39.Name = "pnl39"
        Me.pnl39.Size = New System.Drawing.Size(40, 40)
        Me.pnl39.TabIndex = 47
        '
        'pnl37
        '
        Me.pnl37.BackColor = System.Drawing.Color.Black
        Me.pnl37.Location = New System.Drawing.Point(164, 164)
        Me.pnl37.Name = "pnl37"
        Me.pnl37.Size = New System.Drawing.Size(40, 40)
        Me.pnl37.TabIndex = 45
        '
        'pnl31
        '
        Me.pnl31.BackColor = System.Drawing.Color.Black
        Me.pnl31.Location = New System.Drawing.Point(246, 123)
        Me.pnl31.Name = "pnl31"
        Me.pnl31.Size = New System.Drawing.Size(40, 40)
        Me.pnl31.TabIndex = 39
        '
        'pnl29
        '
        Me.pnl29.BackColor = System.Drawing.Color.Black
        Me.pnl29.Location = New System.Drawing.Point(164, 123)
        Me.pnl29.Name = "pnl29"
        Me.pnl29.Size = New System.Drawing.Size(40, 40)
        Me.pnl29.TabIndex = 37
        '
        'pnl32
        '
        Me.pnl32.BackColor = System.Drawing.Color.Black
        Me.pnl32.Location = New System.Drawing.Point(287, 123)
        Me.pnl32.Name = "pnl32"
        Me.pnl32.Size = New System.Drawing.Size(40, 40)
        Me.pnl32.TabIndex = 40
        '
        'pnl30
        '
        Me.pnl30.BackColor = System.Drawing.Color.Black
        Me.pnl30.Location = New System.Drawing.Point(205, 123)
        Me.pnl30.Name = "pnl30"
        Me.pnl30.Size = New System.Drawing.Size(40, 40)
        Me.pnl30.TabIndex = 38
        '
        'pnl28
        '
        Me.pnl28.BackColor = System.Drawing.Color.Black
        Me.pnl28.Location = New System.Drawing.Point(123, 123)
        Me.pnl28.Name = "pnl28"
        Me.pnl28.Size = New System.Drawing.Size(40, 40)
        Me.pnl28.TabIndex = 36
        '
        'pnl27
        '
        Me.pnl27.BackColor = System.Drawing.Color.Black
        Me.pnl27.Location = New System.Drawing.Point(82, 123)
        Me.pnl27.Name = "pnl27"
        Me.pnl27.Size = New System.Drawing.Size(40, 40)
        Me.pnl27.TabIndex = 35
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(93, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 13)
        Me.Label2.TabIndex = 85
        Me.Label2.Text = "Numbers 1 - 50"
        '
        'pnl24
        '
        Me.pnl24.BackColor = System.Drawing.Color.Black
        Me.pnl24.Location = New System.Drawing.Point(287, 82)
        Me.pnl24.Name = "pnl24"
        Me.pnl24.Size = New System.Drawing.Size(40, 40)
        Me.pnl24.TabIndex = 32
        '
        'pnlResults
        '
        Me.pnlResults.BackColor = System.Drawing.Color.White
        Me.pnlResults.Controls.Add(Me.pnl50)
        Me.pnlResults.Controls.Add(Me.pnl41)
        Me.pnlResults.Controls.Add(Me.pnl36)
        Me.pnlResults.Controls.Add(Me.pnl35)
        Me.pnlResults.Controls.Add(Me.pnl34)
        Me.pnlResults.Controls.Add(Me.pnl33)
        Me.pnlResults.Controls.Add(Me.pnl49)
        Me.pnlResults.Controls.Add(Me.pnl9)
        Me.pnlResults.Controls.Add(Me.pnl20)
        Me.pnlResults.Controls.Add(Me.pnl23)
        Me.pnlResults.Controls.Add(Me.pnl22)
        Me.pnlResults.Controls.Add(Me.pnl26)
        Me.pnlResults.Controls.Add(Me.pnl5)
        Me.pnlResults.Controls.Add(Me.pnl38)
        Me.pnlResults.Controls.Add(Me.pnl25)
        Me.pnlResults.Controls.Add(Me.pnl18)
        Me.pnlResults.Controls.Add(Me.pnl17)
        Me.pnlResults.Controls.Add(Me.pnl8)
        Me.pnlResults.Controls.Add(Me.pnl6)
        Me.pnlResults.Controls.Add(Me.pnl47)
        Me.pnlResults.Controls.Add(Me.pnl48)
        Me.pnlResults.Controls.Add(Me.pnl46)
        Me.pnlResults.Controls.Add(Me.pnl40)
        Me.pnlResults.Controls.Add(Me.pnl45)
        Me.pnlResults.Controls.Add(Me.pnl44)
        Me.pnlResults.Controls.Add(Me.pnl43)
        Me.pnlResults.Controls.Add(Me.pnl42)
        Me.pnlResults.Controls.Add(Me.pnl39)
        Me.pnlResults.Controls.Add(Me.pnl37)
        Me.pnlResults.Controls.Add(Me.pnl31)
        Me.pnlResults.Controls.Add(Me.pnl29)
        Me.pnlResults.Controls.Add(Me.pnl32)
        Me.pnlResults.Controls.Add(Me.pnl30)
        Me.pnlResults.Controls.Add(Me.pnl28)
        Me.pnlResults.Controls.Add(Me.pnl27)
        Me.pnlResults.Controls.Add(Me.pnl24)
        Me.pnlResults.Controls.Add(Me.pnl21)
        Me.pnlResults.Controls.Add(Me.pnl19)
        Me.pnlResults.Controls.Add(Me.pnl2)
        Me.pnlResults.Controls.Add(Me.pnl13)
        Me.pnlResults.Controls.Add(Me.pnl16)
        Me.pnlResults.Controls.Add(Me.pnl15)
        Me.pnlResults.Controls.Add(Me.pnl11)
        Me.pnlResults.Controls.Add(Me.pnl14)
        Me.pnlResults.Controls.Add(Me.pnl12)
        Me.pnlResults.Controls.Add(Me.pnl10)
        Me.pnlResults.Controls.Add(Me.pnl4)
        Me.pnlResults.Controls.Add(Me.pnl7)
        Me.pnlResults.Controls.Add(Me.pnl3)
        Me.pnlResults.Controls.Add(Me.pnl1)
        Me.pnlResults.Location = New System.Drawing.Point(14, 40)
        Me.pnlResults.Name = "pnlResults"
        Me.pnlResults.Size = New System.Drawing.Size(327, 286)
        Me.pnlResults.TabIndex = 92
        '
        'pnl21
        '
        Me.pnl21.BackColor = System.Drawing.Color.Black
        Me.pnl21.Location = New System.Drawing.Point(164, 82)
        Me.pnl21.Name = "pnl21"
        Me.pnl21.Size = New System.Drawing.Size(40, 40)
        Me.pnl21.TabIndex = 29
        '
        'pnl19
        '
        Me.pnl19.BackColor = System.Drawing.Color.Black
        Me.pnl19.Location = New System.Drawing.Point(82, 82)
        Me.pnl19.Name = "pnl19"
        Me.pnl19.Size = New System.Drawing.Size(40, 40)
        Me.pnl19.TabIndex = 27
        '
        'pnl2
        '
        Me.pnl2.BackColor = System.Drawing.Color.Black
        Me.pnl2.Location = New System.Drawing.Point(41, 0)
        Me.pnl2.Name = "pnl2"
        Me.pnl2.Size = New System.Drawing.Size(40, 40)
        Me.pnl2.TabIndex = 10
        '
        'pnl13
        '
        Me.pnl13.BackColor = System.Drawing.Color.Black
        Me.pnl13.Location = New System.Drawing.Point(164, 41)
        Me.pnl13.Name = "pnl13"
        Me.pnl13.Size = New System.Drawing.Size(40, 40)
        Me.pnl13.TabIndex = 21
        '
        'pnl16
        '
        Me.pnl16.BackColor = System.Drawing.Color.Black
        Me.pnl16.Location = New System.Drawing.Point(287, 41)
        Me.pnl16.Name = "pnl16"
        Me.pnl16.Size = New System.Drawing.Size(40, 40)
        Me.pnl16.TabIndex = 1
        '
        'pnl15
        '
        Me.pnl15.BackColor = System.Drawing.Color.Black
        Me.pnl15.Location = New System.Drawing.Point(246, 41)
        Me.pnl15.Name = "pnl15"
        Me.pnl15.Size = New System.Drawing.Size(40, 40)
        Me.pnl15.TabIndex = 23
        '
        'pnl11
        '
        Me.pnl11.BackColor = System.Drawing.Color.Black
        Me.pnl11.Location = New System.Drawing.Point(82, 41)
        Me.pnl11.Name = "pnl11"
        Me.pnl11.Size = New System.Drawing.Size(40, 40)
        Me.pnl11.TabIndex = 19
        '
        'pnl14
        '
        Me.pnl14.BackColor = System.Drawing.Color.Black
        Me.pnl14.Location = New System.Drawing.Point(205, 41)
        Me.pnl14.Name = "pnl14"
        Me.pnl14.Size = New System.Drawing.Size(40, 40)
        Me.pnl14.TabIndex = 22
        '
        'pnl12
        '
        Me.pnl12.BackColor = System.Drawing.Color.Black
        Me.pnl12.Location = New System.Drawing.Point(123, 41)
        Me.pnl12.Name = "pnl12"
        Me.pnl12.Size = New System.Drawing.Size(40, 40)
        Me.pnl12.TabIndex = 20
        '
        'pnl10
        '
        Me.pnl10.BackColor = System.Drawing.Color.Black
        Me.pnl10.Location = New System.Drawing.Point(41, 41)
        Me.pnl10.Name = "pnl10"
        Me.pnl10.Size = New System.Drawing.Size(40, 40)
        Me.pnl10.TabIndex = 18
        '
        'pnl4
        '
        Me.pnl4.BackColor = System.Drawing.Color.Black
        Me.pnl4.Location = New System.Drawing.Point(123, 0)
        Me.pnl4.Name = "pnl4"
        Me.pnl4.Size = New System.Drawing.Size(40, 40)
        Me.pnl4.TabIndex = 12
        '
        'pnl7
        '
        Me.pnl7.BackColor = System.Drawing.Color.Black
        Me.pnl7.Location = New System.Drawing.Point(246, 0)
        Me.pnl7.Name = "pnl7"
        Me.pnl7.Size = New System.Drawing.Size(40, 40)
        Me.pnl7.TabIndex = 15
        '
        'pnl3
        '
        Me.pnl3.BackColor = System.Drawing.Color.Black
        Me.pnl3.Location = New System.Drawing.Point(82, 0)
        Me.pnl3.Name = "pnl3"
        Me.pnl3.Size = New System.Drawing.Size(40, 40)
        Me.pnl3.TabIndex = 11
        '
        'pnl1
        '
        Me.pnl1.BackColor = System.Drawing.Color.Black
        Me.pnl1.Location = New System.Drawing.Point(0, 0)
        Me.pnl1.Name = "pnl1"
        Me.pnl1.Size = New System.Drawing.Size(40, 40)
        Me.pnl1.TabIndex = 9
        '
        'pnlPowerBall
        '
        Me.pnlPowerBall.BackColor = System.Drawing.Color.Black
        Me.pnlPowerBall.Location = New System.Drawing.Point(355, 40)
        Me.pnlPowerBall.Name = "pnlPowerBall"
        Me.pnlPowerBall.Size = New System.Drawing.Size(93, 93)
        Me.pnlPowerBall.TabIndex = 81
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(352, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 87
        Me.Label5.Text = "Power Ball  "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(463, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 91
        Me.Label3.Text = "Drum"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(821, 550)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.pnlDrum)
        Me.Controls.Add(Me.pnlPowerDrum)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnPowerBall)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.pnlResults)
        Me.Controls.Add(Me.pnlPowerBall)
        Me.Name = "Form1"
        Me.Text = "Lotto"
        Me.pnlResults.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tmrPower As Timer
    Friend WithEvents pnl50 As Panel
    Friend WithEvents pnl41 As Panel
    Friend WithEvents pnl36 As Panel
    Friend WithEvents pnl35 As Panel
    Friend WithEvents pnl34 As Panel
    Friend WithEvents pnl33 As Panel
    Friend WithEvents btnClear As Button
    Friend WithEvents pnlDrum As Panel
    Friend WithEvents pnl49 As Panel
    Friend WithEvents pnl9 As Panel
    Friend WithEvents pnl20 As Panel
    Friend WithEvents pnlPowerDrum As Panel
    Friend WithEvents pnl23 As Panel
    Friend WithEvents btnNext As Button
    Friend WithEvents pnl22 As Panel
    Friend WithEvents pnl26 As Panel
    Friend WithEvents pnl5 As Panel
    Friend WithEvents pnl38 As Panel
    Friend WithEvents pnl25 As Panel
    Friend WithEvents tmrBalls As Timer
    Friend WithEvents btnPowerBall As Button
    Friend WithEvents pnl18 As Panel
    Friend WithEvents pnl17 As Panel
    Friend WithEvents pnl8 As Panel
    Friend WithEvents pnl6 As Panel
    Friend WithEvents pnl47 As Panel
    Friend WithEvents pnl48 As Panel
    Friend WithEvents pnl46 As Panel
    Friend WithEvents pnl40 As Panel
    Friend WithEvents pnl45 As Panel
    Friend WithEvents pnl44 As Panel
    Friend WithEvents pnl43 As Panel
    Friend WithEvents pnl42 As Panel
    Friend WithEvents pnl39 As Panel
    Friend WithEvents pnl37 As Panel
    Friend WithEvents pnl31 As Panel
    Friend WithEvents pnl29 As Panel
    Friend WithEvents pnl32 As Panel
    Friend WithEvents pnl30 As Panel
    Friend WithEvents pnl28 As Panel
    Friend WithEvents pnl27 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents pnl24 As Panel
    Friend WithEvents pnlResults As Panel
    Friend WithEvents pnl21 As Panel
    Friend WithEvents pnl19 As Panel
    Friend WithEvents pnl2 As Panel
    Friend WithEvents pnl13 As Panel
    Friend WithEvents pnl16 As Panel
    Friend WithEvents pnl15 As Panel
    Friend WithEvents pnl11 As Panel
    Friend WithEvents pnl14 As Panel
    Friend WithEvents pnl12 As Panel
    Friend WithEvents pnl10 As Panel
    Friend WithEvents pnl4 As Panel
    Friend WithEvents pnl7 As Panel
    Friend WithEvents pnl3 As Panel
    Friend WithEvents pnl1 As Panel
    Friend WithEvents pnlPowerBall As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
End Class
