﻿Public Class clsShuffle

    Const intSize As Integer = 20
    Public intMin As Integer
    Public intMax As Integer

    Private dbSize(intSize - 1) As Double
    Private intThird As Integer
    Private intHalf As Integer

    Public dbRand As Double
    Public intRand As Integer

    Public Sub Shuffle(ByVal dbVal As Double)

        Dim stVal As String
        Dim i As Integer

        Take()

        stVal = Str$(dbVal)

        For i = 1 To Len(stVal)

            Mix(1 / Asc(Mid$(stVal, i, 1)))

        Next

        Randomize(Rnd(dbSize(intThird) * Math.Sign(dbVal)))

        For i = 1 To intSize * 2.5

            Mix(Rnd())

        Next

    End Sub

    Public ReadOnly Property RandomDouble() As Double

        Get

            intThird = (intThird + 1) Mod intSize
            intHalf = (intHalf + 1) Mod intSize

            dbSize(intThird) += dbSize(intThird) + Rnd()
            dbSize(intThird) = dbSize(intThird) - Int(dbSize(intThird))

            dbRand = dbSize(intThird)

            Return dbRand

        End Get

    End Property


    Public ReadOnly Property RandomInt() As Integer

        Get

            intRand = Int(RandomDouble() * intMax - intMin + 1) + intMin

            Return intRand

        End Get

    End Property

    Private Sub Take()

        Dim i As Integer

        For i = 1 To intSize - 1

            dbSize(i) = 1 / i

        Next

        intThird = intSize / 2
        intHalf = intSize / 3

        If intThird = intHalf Then

            intThird = intThird + 1

        End If

    End Sub

    Private Sub Mix(ByVal dbVal As Double)

        intThird = (intThird + 1) Mod intSize
        intHalf = (intHalf + 1) Mod intSize

        dbSize(intThird) += dbSize(intThird) + dbVal
        dbSize(intThird) = dbSize(intThird) - Int(dbSize(intThird))

    End Sub

End Class
