﻿Imports System
Imports System.IO
Imports System.Text
Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class Form1

    Const iMax As Integer = 56
    Const iPowerMax As Integer = 46

    Private blnShow As Boolean = False

    Dim Balls(50)
    Dim PowerBalls(40)

    Dim cShuffleBalls As New clsShuffle
    Dim cShufflePowerBalls As New clsShuffle

    Dim intPowerBall As Integer

    Private Sub tmrBalls_Tick(sender As Object, e As System.EventArgs) Handles tmrBalls.Tick

        blnShow = True
        pnlDrum.Invalidate()

    End Sub

    Private Sub Display(ByVal iBall As Integer)

        If iBall = 1 Then

            blnShow = True
            pnl1.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 2 Then

            blnShow = True
            pnl2.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 3 Then

            blnShow = True
            pnl3.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 4 Then

            blnShow = True
            pnl4.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 5 Then

            blnShow = True
            pnl5.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 6 Then

            blnShow = True
            pnl6.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 7 Then

            blnShow = True
            pnl7.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 8 Then

            blnShow = True
            pnl8.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 9 Then

            blnShow = True
            pnl9.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 10 Then

            blnShow = True
            pnl10.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 11 Then

            blnShow = True
            pnl11.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 12 Then

            blnShow = True
            pnl12.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 13 Then

            blnShow = True
            pnl13.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 14 Then

            blnShow = True
            pnl14.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 15 Then

            blnShow = True
            pnl15.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 16 Then

            blnShow = True
            pnl16.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 17 Then

            blnShow = True
            pnl17.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 18 Then

            blnShow = True
            pnl18.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 19 Then

            blnShow = True
            pnl19.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 20 Then

            blnShow = True
            pnl20.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 21 Then

            blnShow = True
            pnl21.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 22 Then

            blnShow = True
            pnl22.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 23 Then

            blnShow = True
            pnl23.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 24 Then

            blnShow = True
            pnl24.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 25 Then

            blnShow = True
            pnl25.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 26 Then

            blnShow = True
            pnl26.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 27 Then

            blnShow = True
            pnl27.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 28 Then

            blnShow = True
            pnl28.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 29 Then

            blnShow = True
            pnl29.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 30 Then

            blnShow = True
            pnl30.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 31 Then

            blnShow = True
            pnl31.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 32 Then

            blnShow = True
            pnl32.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 33 Then

            blnShow = True
            pnl33.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 34 Then

            blnShow = True
            pnl34.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 35 Then

            blnShow = True
            pnl35.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 36 Then

            blnShow = True
            pnl36.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 37 Then

            blnShow = True
            pnl37.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 38 Then

            blnShow = True
            pnl38.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 39 Then

            blnShow = True
            pnl39.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 40 Then

            blnShow = True
            pnl40.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 41 Then

            blnShow = True
            pnl41.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 42 Then

            blnShow = True
            pnl42.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 43 Then

            blnShow = True
            pnl43.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 44 Then

            blnShow = True
            pnl44.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 45 Then

            blnShow = True
            pnl45.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 46 Then

            blnShow = True
            pnl46.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 47 Then

            blnShow = True
            pnl47.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 48 Then

            blnShow = True
            pnl48.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 49 Then

            blnShow = True
            pnl49.Invalidate()
            iBall = Nothing
            Exit Sub

        ElseIf iBall = 50 Then

            blnShow = True
            pnl50.Invalidate()
            iBall = Nothing
            Exit Sub

        End If
    End Sub

    Private Sub NextBall(ByVal tmpArray())

        Dim i As Integer
        Dim j As Integer = 0

        tmpArray(0) = tmpArray(0) + 1
        i = tmpArray(0)

        Do

            tmpArray(i) = cShuffleBalls.RandomInt

            Display(tmpArray(i))

            If i > 1 Then

                For j = 1 To (i - 1)

                    If tmpArray(i) = tmpArray(j) Then

                        tmpArray(i) = 0

                    End If

                Next

            End If

        Loop Until tmpArray(i)

    End Sub

    Private Sub frmLotto_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        tmrBalls.Dispose()
        tmrPower.Dispose()

    End Sub

    Private Sub frmLotto_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Randomize()

        cShuffleBalls.Shuffle(Rnd)
        cShufflePowerBalls.Shuffle(Rnd)

        cShuffleBalls.intMin = 1
        cShuffleBalls.intMax = iMax

        cShufflePowerBalls.intMin = 1
        cShufflePowerBalls.intMax = iPowerMax

        tmrBalls.Start()

    End Sub

    Private Sub pnlTumble_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnlDrum.Paint

        Dim i As Integer = 0
        Dim intX As Integer
        Dim intY As Integer

        Dim rRand As New Random
        Dim rctDraw As New Rectangle

        For i = 1 To 50

            intX = rRand.Next(1, 300)
            intY = rRand.Next(1, 400)

            rctDraw.Height = 50
            rctDraw.Width = 50

            rctDraw.Location = New Point(intX, intY)

            e.Graphics.FillEllipse(Brushes.White, rctDraw.X, rctDraw.Y, 50, 50)

            Dim fDraw As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(i.ToString(), fDraw)

            e.Graphics.DrawString(i.ToString(), fDraw, Brushes.Black, (rctDraw.Left + 25) - (StringSize.Width / 2), (rctDraw.Top + 25) - (StringSize.Height / 2))

        Next

        e.Graphics.Clear(Color.Black)
        e.Graphics.Dispose()

    End Sub

    Private Sub btnNext_Click(sender As Object, e As System.EventArgs) Handles btnNext.Click

        If btnNext.Text = "Play again" Then

            btnNext.Text = "Next Ball"
            tmrBalls.Start()

        End If

        Dim i As Integer

        i = Balls(0)

        If i = 5 Then

            For i = 0 To 5

                Balls(i) = 0

            Next

            Exit Sub

        End If

        NextBall(Balls)

        If Balls(0) = 5 Then

            btnNext.Text = "Play again"
            tmrBalls.Stop()
            pnlDrum.Hide()

            pnlPowerDrum.Show()
            tmrPower.Start()

        End If

    End Sub

    Private Sub ClearBalls()

        Dim g As Graphics

        g = pnl1.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl2.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl3.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl4.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl5.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl6.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl7.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl8.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl9.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl10.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl11.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl12.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl13.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl14.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl15.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl16.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl17.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl18.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl19.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl20.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl21.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl22.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl23.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl24.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl25.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl26.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl27.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl28.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl29.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl30.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl31.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl32.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl33.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl34.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl35.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl36.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl37.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl38.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl39.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl40.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl41.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl42.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl43.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl44.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl45.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl46.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl47.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl48.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl49.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnl50.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

        g = pnlPowerBall.CreateGraphics
        g.Clear(Color.Black)
        g.Dispose()

    End Sub

    Private Sub btnClearAll_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click

        ClearBalls()

    End Sub

    Private Sub pnl1_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl1.Paint

        If blnShow Then

            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)

            Dim t As String = "1"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)

            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnlPowerBall_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnlPowerBall.Paint

        If blnShow Then

            Dim rect As New Rectangle
            rect.Height = 93
            rect.Width = 93
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.Yellow, rect.X, rect.Y, 93, 93)
            Dim strPowerBall As String = "Power Ball"
            Dim t As String = intPowerBall.ToString
            Dim f As Font = New Font("Arial", 16, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Width / 2) - (StringSize.Width / 2), (rect.Height / 2) - (StringSize.Height / 2))

            Dim fmb As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim mbStringSize As SizeF = e.Graphics.MeasureString(strPowerBall, fmb)
            e.Graphics.DrawString(strPowerBall, fmb, Brushes.Black, (rect.Left + 47) - (mbStringSize.Width / 2), (rect.Top + 18) - (mbStringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnlPowerDrum_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnlPowerDrum.Paint

        Dim i As Integer = 0
        Dim xPos As Integer
        Dim yPos As Integer
        Dim rr As New Random
        Dim rect As New Rectangle

        For i = 1 To 40
            xPos = rr.Next(1, 300)
            yPos = rr.Next(1, 400)

            rect.Height = 50
            rect.Width = 50
            rect.Location = New Point(xPos, yPos)

            e.Graphics.FillEllipse(Brushes.Yellow, rect.X, rect.Y, 50, 50)

            Dim f As Font = New Font("Arial", 12, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(i.ToString(), f)

            e.Graphics.DrawString(i.ToString(), f, Brushes.Black, (rect.Left + 25) - (StringSize.Width / 2), (rect.Top + 25) - (StringSize.Height / 2))
        Next
        e.Graphics.Clear(Color.Black)
        e.Graphics.Dispose()
    End Sub

    Private Sub tmrPower_Tick(sender As Object, e As System.EventArgs) Handles tmrPower.Tick

        blnShow = True
        pnlPowerDrum.Invalidate()

    End Sub

    Private Sub btnPowerBall_Click(sender As Object, e As System.EventArgs) Handles btnPowerBall.Click

        NextPowerBall(PowerBalls)

        tmrBalls.Stop()
        pnlDrum.Show()
        pnlPowerDrum.Hide()
        tmrPower.Stop()


    End Sub

    Private Sub NextPowerBall(ByVal arrTemp())

        Dim i As Integer
        Dim j As Integer = 0

        arrTemp(0) = arrTemp(0) + 1
        i = arrTemp(0)

        Do

            arrTemp(i) = cShuffleBalls.RandomInt

            DisplayPowerBall(arrTemp(i))

            If i > 1 Then

                For j = 1 To (i - 1)

                    If arrTemp(i) = arrTemp(j) Then

                        arrTemp(i) = 0

                    End If

                Next

            End If

        Loop Until arrTemp(i)

    End Sub

    Private Sub DisplayPowerBall(ByVal intVal As Integer)

        intPowerBall = intVal

        Select Case intPowerBall

            Case 1 To 40

                blnShow = True
                pnlPowerBall.Invalidate()

        End Select

    End Sub


    Private Sub pnl2_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl2.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "2"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl3_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl3.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "3"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl4_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl4.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "4"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl5_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl5.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "5"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl6_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl6.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "6"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl7_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl7.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "7"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl8_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl8.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "8"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl9_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl9.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "9"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl10_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl10.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "10"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl11_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl11.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "11"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl12_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl12.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "12"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl13_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl13.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "13"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl14_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl14.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "14"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl15_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl15.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "15"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl16_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl16.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "16"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl17_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl17.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "17"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl18_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl18.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "18"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl19_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl19.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "19"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl20_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl20.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "20"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl21_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl21.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "21"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl22_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl22.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "22"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl23_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl23.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "23"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl24_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl24.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "24"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl25_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl25.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "25"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl26_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl26.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "26"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl27_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl27.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "27"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl28_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl28.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "28"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl29_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl29.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "29"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl30_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl30.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "30"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl31_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl31.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "31"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl32_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl32.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "32"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl33_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl33.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "33"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl34_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl34.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "34"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl35_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl35.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "35"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl36_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl36.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "36"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl37_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl37.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "37"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl38_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl38.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "38"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl39_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl39.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "39"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl40_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl40.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "40"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl41_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl41.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "41"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl42_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl42.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "42"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl43_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl43.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "43"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl44_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl44.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "44"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl45_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl45.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "45"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl46_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl46.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "46"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl47_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl47.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "47"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl48_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl48.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "48"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl49_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl49.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "49"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub

    Private Sub pnl50_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles pnl50.Paint
        If blnShow Then
            Dim rect As New Rectangle
            rect.Height = 40
            rect.Width = 40
            rect.Location = New Point(0, 0)

            e.Graphics.FillEllipse(Brushes.White, rect.X, rect.Y, 40, 40)
            Dim t As String = "50"
            Dim f As Font = New Font("Arial", 10, FontStyle.Bold)
            Dim StringSize As SizeF = e.Graphics.MeasureString(t, f)
            e.Graphics.DrawString(t, f, Brushes.Black, (rect.Left + 20) - (StringSize.Width / 2), (rect.Top + 20) - (StringSize.Height / 2))
            e.Graphics.Dispose()

        End If
    End Sub


End Class
